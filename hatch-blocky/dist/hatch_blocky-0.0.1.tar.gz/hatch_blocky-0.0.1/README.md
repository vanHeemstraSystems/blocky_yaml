# Hatch Blocky

[![PyPI - Version](https://img.shields.io/pypi/v/hatch-blocky.svg)](https://pypi.org/project/hatch-blocky)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/hatch-blocky.svg)](https://pypi.org/project/hatch-blocky)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install hatch-blocky
```

## License

`hatch-blocky` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.