from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()